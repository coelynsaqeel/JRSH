import { createClient } from '@supabase/supabase-js'

const SB_URL = "https://bodeplbamprefhdrckyp.supabase.co"
const SB_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJvZGVwbGJhbXByZWZoZHJja3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY1NDE1MjUsImV4cCI6MjA5MjExNzUyNX0.Au8NUHC_2eFFuNugM6JybzK6AzKNIUTLuyUo-F772FQ"

export const supabase = createClient(SB_URL, SB_ANON)

/* ── helper wrappers that mirror the old fetch-based API ── */
export const sb = {
  async get(table, query = "") {
    // query is like "?student_id=eq.xxx&order=..."
    // parse it into supabase-js format would be complex, so we keep raw fetch for flexibility
    const res = await fetch(`${SB_URL}/rest/v1/${table}${query}`, {
      headers: {
        "Content-Type": "application/json",
        "apikey": SB_ANON,
        "Authorization": `Bearer ${SB_ANON}`,
      }
    })
    if (!res.ok) {
      const err = await res.text()
      throw new Error(err)
    }
    return res.json()
  },

  async post(table, body) {
    const res = await fetch(`${SB_URL}/rest/v1/${table}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SB_ANON,
        "Authorization": `Bearer ${SB_ANON}`,
        "Prefer": "return=representation",
      },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const err = await res.text()
      throw new Error(err)
    }
    return res.json()
  },

  async patch(table, query, body) {
    const res = await fetch(`${SB_URL}/rest/v1/${table}${query}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "apikey": SB_ANON,
        "Authorization": `Bearer ${SB_ANON}`,
        "Prefer": "return=representation",
      },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const err = await res.text()
      throw new Error(err)
    }
    return res.json()
  },

  async delete(table, query) {
    const res = await fetch(`${SB_URL}/rest/v1/${table}${query}`, {
      method: "DELETE",
      headers: {
        "apikey": SB_ANON,
        "Authorization": `Bearer ${SB_ANON}`,
      },
    })
    if (!res.ok) {
      const err = await res.text()
      throw new Error(err)
    }
    return res.status === 204 ? [] : res.json()
  },

  async uploadFile(bucket, path, file) {
    const res = await fetch(`${SB_URL}/storage/v1/object/${bucket}/${path}`, {
      method: "POST",
      headers: {
        "apikey": SB_ANON,
        "Authorization": `Bearer ${SB_ANON}`,
        "Content-Type": file.type,
      },
      body: file,
    })
    if (!res.ok) {
      const err = await res.text()
      throw new Error(err)
    }
    return `${SB_URL}/storage/v1/object/public/${bucket}/${path}`
  },
}
